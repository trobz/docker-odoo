=========================
openoffice-python
=========================
------------------------------------------------------------
Python libraries for interacting with OpenOffice.org
------------------------------------------------------------

Homepage: http://openoffice-python.origo.ethz.ch/

Aim of this project is to support

    * users writing complex macros for OpenOffice in Python

    * developers interacting with OpenOffice from outside (eg. use
      OpenOffice to print a file)

The library is designed to supports both writing macros (called by
OOo) and interacting with OOo from an external Python programm (using
the UNO bridge).

The "UNO bridge" side is meant to implement a more Pythonic and
high-level interface than Danny Bewers OOoLib. While the "Macro" side
is meant to support writing macros. Well, there will be a big
intersection between these parts :-)

For more information, eg. related projects, please visit
<http://openoffice-python.origo.ethz.ch/>.


