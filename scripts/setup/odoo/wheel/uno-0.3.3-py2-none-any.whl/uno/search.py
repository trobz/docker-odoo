# -*- coding: utf-8 -*-

class UnoSearcher(object):

    def __init__(self):
        pass

    def by_uno_id(self):
        pass
