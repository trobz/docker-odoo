

from base import UnoBaseForm


class UnoForm(UnoBaseForm):
    def __init__(self, *args, **kwargs):
        super(UnoForm, self).__init__(*args, **kwargs)




