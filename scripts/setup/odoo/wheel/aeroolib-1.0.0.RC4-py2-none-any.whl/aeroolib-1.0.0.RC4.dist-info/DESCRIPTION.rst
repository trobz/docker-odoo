aeroolib
=========

A templating library which provides a way to easily output all kind of
different files (odt, ods). Adding support for more filetype is easy:
you just have to create a plugin for this.

aeroolib also provides a report repository allowing you to link python objects
and report together, find reports by mimetypes/name/python objects.


